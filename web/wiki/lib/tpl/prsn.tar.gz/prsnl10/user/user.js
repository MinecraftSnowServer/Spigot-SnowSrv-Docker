/* en: Place for user defined JavaScript - this file can safely be preserved
   when updating. See README for details.
   ATTENTION: Do not forget to activate the template option
              "prsnl10_loaduserjs" (->"Load 'prsnl10/user/user.js'?") in the
              DokuWiki Config Manager! Otherwise, any changes to this file
              won't have any effect!
   
   de: Ort für benutzerdefiniertes JavaScript - Diese Datei kann beim
   Durchführen von Updates ohne Risiko beibehalten werden. Konsultieren Sie
   die README für Detailinformationen.

   ACHTUNG: Vergessen Sie nicht die Template-Option "prsnl10_loaduserjs"
            (->"Datei 'prsnl10/user/user.js' laden?") im DokuWiki Config
            Manager zu aktivieren! Andernfalls werden sämtliche Änderungen an
            dieser Datei ohne Auswirkungen bleiben! */

